"""AI 문서 검토 시스템 UI 모듈."""

from ui.main_window import MainWindow

__all__ = ["MainWindow"]
